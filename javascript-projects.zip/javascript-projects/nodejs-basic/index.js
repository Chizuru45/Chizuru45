const message = (name) => {
    console.log(`Hello ${name}`);
}

message('JavaScript');