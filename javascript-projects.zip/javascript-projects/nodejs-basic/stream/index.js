const fs = require('fs');
const { resolve} = require('path');

const readableStream = fs.createReadStream(resolve(__dirname, './article.txt'), {
    highWaterMark: 10
});
//  console.log(type(readableStram)); // output = object

// Event readable akan dibangkitkan ketika buffer sudah memiliki ukuran
// sesuai dengan nilai yang ditetapkan pada properti highWaterMark
// dalam arti buffer sudah dibaca

readableStream.on('readable', () => {
    try {
        process.stdout.writableCorked(`[${readableStream.read()}]`);
    }   catch(error) {
            // catch the error when the chunk cannot be read.
    }
});

// Buffer di dalam stream adalah memori sementara yang digunakan oleh
// stream dalam menyimpan data hingga data tersebut dikonsumsi

// Kemudia event end akan dibangkitkan setelah proses stream selesai
readableStream.on('end', () => {
    console.log('Done');
});